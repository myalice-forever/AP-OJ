//
// Created by 胡文菁 on 2022/3/25.
//

#ifndef OJ__SIMPLEBANK_H_
#define OJ__SIMPLEBANK_H_

#include <iostream>
#include <vector>
using namespace std;

struct trans{
  int account1;
  int account2;
  int money;
};

struct depo{
  int account;
  int money;
};

struct get_money{
  int account;
  int money;
};

class SimpleBank{
 public:
  SimpleBank(const int *balance, int length);
// 构造函数，传入一个数组与对应数组的长度。
// 整数数组balance存储银行系统中的账户余额， balance[i] 表示账户编号为(i + 1)账户的初始余额
// 输入保证数组各项元素是非负的
  ~SimpleBank();
// 析构函数
  bool transfer(int account1, int account2, int money);
// 转账操作，用于从账户编号为account1的账户，向账户编号为account2的账户转账，转账数值为money
// 当两账户均存在于当前系统且转出账户account1有足够余额时，执行转账操作并返回执行成功true。否则返回执行失败false
// account1、account2、money调用时保证均为正，且account1与account2不同
  bool deposit(int account, int money);
// 存款操作，用于向账户标号为account的账户中，追加money数值的存款
// 当account账户存在于当前系统，执行成功返回true。否则执行失败返回false
// account、money调用时保证为正
  bool withdraw(int account, int money);
// 取款操作，用于从账户编号为account的账户中，取出money数值。
// 当account账户存在于当前系统且账户有足够余额时，执行成功并返回true。否则执行失败返回false。
// account、money调用时保证为正
  int operator[](int account) const;
// 访问数组元素操作符“[]”重载
// SimpleBank simpleBank(init_balance, n)；
// simpleBank[i]用于访问第i个账户的余额（账户编号从1到n）
// account调用时保证为正，超出账户编号范围时返回1
  SimpleBank &operator=(const SimpleBank &s);
// 赋值操作符重载
// 保证使用此操作符后，两个银行系统完全一致，但对其中一个系统进行操作不会对另一个系统产生影响。
  bool resize(int count);
// 扩容操作。将原来的n个账户拓展到count个账户。
// 当 count>n 时，要求原有数据不变，扩容的新账户余额均为0，并返回true表示执行成功。 否则返回false表示执行失败。
  bool rollback(int number);
// 回滚操作。回滚 number 个成功的转账、存款、取款操作
// 当 number > 目前系统已经记录下的 成功转账、存款与取款操作总数 时，不执行任何操作并返回false。
// 否则，回滚最近 number 个成功的转账、存款与取款操作并返回true。
// ** 特别提醒 赋值操作符重载 中也需要将操作历史一同复制 **
 private:
  vector<int> store;
  vector<int> history;
  vector<trans> store_trans;
  vector<depo> store_deposit;
  vector<get_money> store_withdraw;
};
#endif //OJ__SIMPLEBANK_H_
